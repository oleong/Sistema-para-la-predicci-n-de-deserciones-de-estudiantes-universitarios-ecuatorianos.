from django.apps import AppConfig


class PrediccionConfig(AppConfig):
    name = 'prediccion'
